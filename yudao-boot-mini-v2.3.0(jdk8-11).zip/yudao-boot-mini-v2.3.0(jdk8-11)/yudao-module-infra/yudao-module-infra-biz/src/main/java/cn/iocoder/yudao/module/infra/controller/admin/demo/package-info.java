/**
 * 代码生成示例
 *
 * 1. demo01：单表（增删改查）
 * 2. demo02：单表（树形结构）
 * 3. demo03：主子表（标准模式）+ 主子表（ERP 模式）+ 主子表（内嵌模式）
 */
package cn.iocoder.yudao.module.infra.controller.admin.demo;
/**
 * Banner 用于在 console 控制台，打印开发文档、接口文档等
 *
 * @author 芋道源码
 */
package cn.iocoder.yudao.framework.banner;
